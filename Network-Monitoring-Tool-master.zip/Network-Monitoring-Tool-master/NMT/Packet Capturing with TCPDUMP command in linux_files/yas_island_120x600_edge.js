
(function(compId){var _=null,y=true,n=false,zy='scaleY',x32='chevCopy',e24='${copy1}',x2='5.0.0',x5='rgba(0,0,0,0)',e19='${chev_anim}',zx='scaleX',x13='rgba(192,192,192,0.00)',cl='clip',x33='1',x30='0',x14='solid',m='rect',x25='0px',i='none',x22='rect(@@0@@px @@1@@px @@2@@px @@3@@px)',x3='6.0.0.400',o='opacity',lf='left',e35='${chev}',e34='${chevCopy}',x29='chev',x4='both',x28='auto',x26='980px',e23='${keyline_h}',x1='6.0.0',e18='${copy3}',x15='rgba(255,255,255,1)',tp='top',e17='${img_2jpg}',e21='${keyline_v}',g='image',x27='450px',e20='${copy2}',e16='${logo_english}';var g9='copy2.png',g11='keyline_v.png',g8='copy1.png',g12='keyline_h.png',g6='img_3.jpg',g31='chev22.png',g7='logo_english.png',g10='copy3.png';var im='images/',aud='media/',vid='media/',js='js/',fonts={},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x2,b:x3,stf:i,cg:x4,rI:n,cn:{dom:[{id:'img_2jpg',t:g,r:['-250px','-55px','401px','701px','auto','auto'],f:[x5,im+g6,'0px','0px'],tf:[[],[],[],['0.95','0.95']]},{id:'logo_english',t:g,r:['0px','0px','120px','600px','auto','auto'],f:[x5,im+g7,'0px','0px']},{id:'copy1',t:g,r:['0','0','120px','600px','auto','auto'],f:[x5,im+g8,'0px','0px']},{id:'copy2',t:g,r:['0','0','120px','600px','auto','auto'],f:[x5,im+g9,'0px','0px']},{id:'copy3',t:g,r:['-2px','0','120px','600px','auto','auto'],f:[x5,im+g10,'0px','0px']},{id:'chev_anim',symbolName:'chev_anim',t:m,r:['-296px','200px','980','450','auto','auto'],tf:[[],[],[],['0.45','0.45']]},{id:'keyline_v',t:g,r:['0','0','120px','600px','auto','auto'],cl:'rect(0px 128px 609px 0px)',f:[x5,im+g11,'0px','0px']},{id:'keyline_h',t:g,r:['0','0','120px','600px','auto','auto'],cl:'rect(0px 128px 615px 0px)',f:[x5,im+g12,'0px','0px']},{id:'keyline_outer',t:m,r:['0px','0px','118px','598px','auto','auto'],f:[x13],s:[1,"rgba(59,59,59,1.00)",x14]}],style:{'${Stage}':{isStage:true,r:['null','null','120px','600px','auto','auto'],overflow:'hidden',f:[x15]}}},tt:{d:15000,a:y,data:[["eid32",o,683,817,"easeInQuad",e16,'0','1'],["eid51",tp,0,9683,"easeInOutSine",e17,'-100px','-55px'],["eid31",lf,9899,0,"linear",e18,'-2px','-2px'],["eid53",zy,0,9683,"easeInOutSine",e17,'1','0.95'],["eid52",zx,0,9683,"easeInOutSine",e17,'1','0.95'],["eid20",o,9330,750,"linear",e19,'0','1'],["eid14",o,5900,750,"linear",e20,'0.000000','1'],["eid15",o,8400,750,"linear",e20,'1','0.000000'],["eid19",cl,0,1750,"easeInOutCubic",e21,[0,128,0,0],[0,128,609,0],{vt:x22}],["eid18",cl,0,1750,"easeInOutCubic",e23,[0,0,615,0],[0,128,615,0],{vt:x22}],["eid49",lf,0,9683,"easeInOutSine",e17,'-5px','-250px'],["eid12",o,1250,750,"linear",e24,'0','1'],["eid13",o,3750,750,"linear",e24,'1','0'],["eid30",lf,9899,0,"linear",e19,'-296px','-296px'],["eid16",o,9330,750,"linear",e18,'0','1']]}},"chev_anim":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x25,x25,x26,x27,x28,x28],id:x29,o:x30,t:g,f:[x5,im+g31,x25,x25]},{r:[x25,x25,x26,x27,x28,x28],id:x32,o:x33,t:g,f:[x5,im+g31,x25,x25]}],style:{'${symbolSelector}':{r:[_,_,x26,x27]}}},tt:{d:1500,a:y,data:[["eid69",o,0,0,"linear",e34,'1','1'],["eid70",o,750,0,"linear",e34,'1','1'],["eid45",tp,0,0,"linear",e35,'0px','0px'],["eid44",tp,750,0,"linear",e35,'0px','0px'],["eid64",lf,0,750,"linear",e35,'0px','15px'],["eid66",lf,750,750,"linear",e35,'15px','30px'],["eid62",lf,750,0,"linear",e34,'0px','0px'],["eid50",tp,0,0,"linear",e34,'0px','0px'],["eid26",o,0,750,"linear",e35,'0','1'],["eid58",o,750,750,"linear",e35,'1','0']]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-38400869");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",9330,function(sym,e){sym.getSymbol("chev_anim").play(2);});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",15000,function(sym,e){if(!sym.loop){sym.loop=1;}
sym.loop+=1;if(sym.loop<=2){sym.play(0);}});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${Stage}","click",function(sym,e){window.open(window.clickTag);});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'chev_anim'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",1500,function(sym,e){sym.play(2);});
//Edge binding end
})("chev_anim");
//Edge symbol end:'chev_anim'
})})(AdobeEdge.$,AdobeEdge,"EDGE-38400869");