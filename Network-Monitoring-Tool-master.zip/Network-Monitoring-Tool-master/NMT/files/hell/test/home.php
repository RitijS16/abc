<html>
<head>
<title>Welcome</title>
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="header" class="container">
                <div id="logo">
                        <h1>NMT</h1>
                        <span>Welcome</span> </div>
                <div id="menu">
                        <ul>
                                <li class="current_page_item"><a href="home.php" accesskey="1" title=""><font size=4>HOME</font></a></li>
                                <!--li><a href="ipv4.php" accesskey="2" title=""><font size=4>IPv4</font></a></li>
                                <li><a href="ipv6.php" accesskey="3" title=""><font size=4>IPv6</font></a></li>-->
                        </ul>
                </div>
</div>
<div id="wrapper3" align="center">
				<a href="ip4.php" class="button button-small">IPv4</a><br>
				<a href="ip6.php" class="button button-small">IPv6</a><br>
                                <a href="recons.php" class="button button-small">Reconstruction</a><br>
</div>
</body>
</html>

