<div id="Sign-In">
<fieldset style="width:30%"><legend>LOG-IN HERE</legend>
<form method="POST" action="logincheck.php">
User <br><input type="text" name="username" size="40"><br>
Password <br><input type="password" name="password" size="40"><br>
<input id="button" type="submit" name="submit" value="Log-In">
</form>
</fieldset>
</div>
    
