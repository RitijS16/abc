<html>
<td>RollNo</td>
<td width="6">:</td>
<td><input name="rollno" type="text" id="rollno"></td><br>
<td>Name</td>
<td width="294"><input name="name" type="text" id="name"></td><br>
<td>Address</td>
<td><input name="address" type="text" id="address"></td><br>
<td><input type="submit" name="Submit" value="Submit"></td>
</html>

