<!Doctype HTML>
<html>
<head>
<title>Register page</title>
</head>
<body>
<form name="myform2" action="try3c.php" method="post">

<div style="background-color:#a6a6a6;width:40%;border-style:solid;margin-left:25%;margin-top:10%;padding:2%;">
<table>
<tr>
<td style="text-align:right;">First &nbsp;&nbsp;Name: </td><td><input type="text" name="fname">
</td>
</tr>
<tr>
<td style="text-align:right;">Last &nbsp;&nbsp;Name:</td> <td><input type="text" name="lname"></td></tr>

<tr><td style="text-align:right;">E-Mail: </td><td><input type="text" name="email"></td>
</tr>
<tr>
<td style="text-align:right;">Username:</td><td><input type="text" name="user"></td>
<tr><td style="text-align:right;">Password:</td><td><input type="password" name="pass"></td></tr>
<tr><td>Retype&nbsp; Password:</td><td><input type="password" name="pass"></td></tr>

<tr style="text-align:center;"><td colspan="2" style="padding:3%;"><button id="Save" value="save" name="save">REGISTER</button>
</td></tr>
</table>
</form>
</div>
</body>
</html>
