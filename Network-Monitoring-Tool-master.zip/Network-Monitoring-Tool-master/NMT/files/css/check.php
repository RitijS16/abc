<?php
system('cat file.txt');
echo "done";
?>