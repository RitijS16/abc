# Network-Monitoring-Tool

This is a network monitoring tool build using html, php, css etc. 
It uses the tcpdump command in linux to capture different packets and then sorts them according to different categories 
like UDP, IPv4,ARP.

This project was developed as a summer internship program at IIT - Kanpur in summers 2016.

# Requirements

1. PHP 
2. MySQL database
3. internet Browser

# Tools and Languages Used - 
1. PHP
2. MySQL
3. HTML
4. Shell Scripting
5. CSS
6. tcpdump command in linux



![Alt text](https://github.com/jatin96/Network-Monitoring-Tool/blob/master/Screenshot%20from%202016-06-07%2012:22:25.png)
